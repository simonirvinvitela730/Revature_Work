
public class Example {
	public static void main(String[] args) {
		int i = 200;
		short s = (short)i;
		System.out.println(s);
		
		double d = (double)i;
		System.out.println(d);
		
		byte b = (byte)i;
		System.out.println(b);
	}
}
