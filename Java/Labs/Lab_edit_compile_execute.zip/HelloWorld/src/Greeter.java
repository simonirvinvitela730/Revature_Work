
public class Greeter {
	public static void main(String[] args) {
		System.out.println("What's up?");
	}
}
