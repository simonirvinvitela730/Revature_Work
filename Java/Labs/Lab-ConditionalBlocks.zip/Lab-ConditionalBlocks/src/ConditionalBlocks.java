
public class ConditionalBlocks {
	public static void main(String[] args) {
		 boolean b = false;  
		  
		   if (b){  
		  System.out.println("inside the if-statement");  
		   }  
		  
		   System.out.println("Outside of the if-statement");  
		 }  
}
