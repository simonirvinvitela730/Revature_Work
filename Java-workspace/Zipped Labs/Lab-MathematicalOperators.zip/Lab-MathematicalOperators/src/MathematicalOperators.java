
public class MathematicalOperators {
	public static void main(String[] args) {
		int x = 5;
		int y = 3;
		int z;

		//simple addition
		
		z = x+y;
		System.out.println(z);

		//simple subtraction
		z = x-y;
		System.out.println(z);
		//simple multiplication
		z = x*y;
		System.out.println(z);
		//simple division
		z = x/y;
		System.out.println(z);
		//simple modulus
		z = x%y;
		System.out.println(z);
		//float versus integer
		float f = 3.6f;
		int i = 22;
		double result = f + i;
		System.out.println(result);
		 }
	}
