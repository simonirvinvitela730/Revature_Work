
public class ReturnTypes {
	 public static void main(String[] args) {
	        ReturnTypes rt = new ReturnTypes();
	        rt.returnNothing();
	        char a = rt.returnChar();

	        System.out.println("The value of a is: " + a);
	    }

	    public void returnNothing(){
	        System.out.println("Inside of a void method");
	    }

	    public char returnChar(){
	        return 'a';
	    }
}
